(function (Drupal, once) {
  Drupal.behaviors.belgiumPublicThemeFaq = {
    attach(context) {
      once('faq-enhancement', '.faq-item', context).forEach((item) => {
        item.addEventListener('toggle', () => {
          if (item.open) {
            item.classList.add('is-open');
          } else {
            item.classList.remove('is-open');
          }
        });
      });
    }
  };
})(Drupal, once);
